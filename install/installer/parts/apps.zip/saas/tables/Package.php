<?php
/**
 * Clase de acceso a la tabla package
 *
 * Esta tabla se utiliza para package
 * @author	Henry Isaac Galvez Thuillier <henry@aquainteractive.com.mx>
 * @copyright	Copyright (c) 2008, {@link http://www.aquainteractive.com Aqua
 * Interactive}
 * @package	App.Saas
 * @since	Revisión $id$ $date$
 * @subpackage	Tables
 * @version	2.0.0
 */

/**
 * Clase de acceso a la tabla package
 *
 * Esta tabla se utiliza para package
 * @package	App.Saas
 * @subpackage	Tables
 */
class App_saas_tables_Package extends Mekayotl_database_dal_AccessAbstract
{

    /**
     * Configura el objeto.
     */

    public function __construct()
    {
        $this->_table = 'package';
        $this->_baseClass = 'App_saas_vo_Package';
        $this->_keys = array(
                'package',
        );
        parent::__construct();
    }
}

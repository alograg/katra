<?php

/**
 * Lógica de las cuentas de la aplicación.
 *
 * Métodos manejo de cuentas.
 * @author Henry <henry@aquainteractive.com.mx>
 * @copyright Copyright (c) 2012, {@link http://www.aquainteractive.com Aqua
 * Interactive}
 * @package App.SaaS
 * @since Revisión $id$ $date$
 * @subpackage Floyd
 * @version 1.0.0
 */

/**
 * Lógica de las cuentas de la aplicación.
 *
 * Métodos manejo de cuentas.
 * @package App.SaaS
 * @subpackage SaaS
 */
class App_saas_Account extends Mekayotl_database_dal_BusinessAbstract
{

    /**
     * Acceso a los miembros.
     * @var App_SaaS_tables_Account
     */

    protected $_account = NULL;

    public function __construct()
    {
        $this->_account = new App_saas_tables_Account();
        $this->setAdapter(Mekayotl::adapterFactory('Database'));
    }

    /**
     * Realiza un ingrso a la aplicacion.
     * @param string $account
     * @return array Informacion de la cuenta ingresado.
     */

    protected function info($account)
    {
        if (is_null($account)) {
            return FALSE;
        }
        $filter = new App_saas_vo_Account();
        $filter->setNull();
        $accounts = $this->_account;
        $filter->account = $account;
        $accounts->read($filter);
        if ($accounts->count() != 1) {
            return FALSE;
        }
        $account = $accounts->current();
        return $account;
    }

    /**
     * Actualiza datos de la cuenta
     * @param array $account
     * @return App_saas_vo_Account
     */

    protected function update($account)
    {
        if (is_null($account)) {
            return FALSE;
        }
        $filter = new App_saas_vo_Account($account);
        $accounts = $this->_account;
        $accounts->update($filter);
        $filter->setNull();
        $filter->account = $account['account'];
        $accounts->read($filter);
        if ($accounts->count() != 1) {
            return FALSE;
        }
        $account = $accounts->current();
        return $account;
    }
}

<?php
//namespace Saas
/**
 * Manejador de servicios SaaS
 * @author $Author$
 * @copyright Copyright (c) 2008, {@link http://www.aquainteractive.com Aqua
 * Interactive}
 * @package aqua.tools
 * @since $Date$
 * @subpackage Monitor
 * @version $Id$
 */

/**
 * Clase principal de la aplicación
 *
 * Trae el controladores y otras cosas.
 * @package aqua.tools
 * @subpackage Monitor
 */
class App_Saas extends Mekayotl_ApplicationAbstract
{
    /**#@+
     * @access protected
     */

    protected $_className = __CLASS__;
    /**
     * La version de la aplicación
     * @var string
     * @static
     */
    protected static $_version = '2.0.$Id$';
    /**
     * Constructor de la aplicación con sus adaptaciones
     * @param array $config La configuración de la instalación
     * @param boolean $autorun Si se auto ejecuta la aplicación al ser creada
     * @access public
     */

    public function __construct($config = Null, $autorun = false)
    {
        Mekayotl_tools_Security::createSession();
    }

    /**
     * (non-PHPdoc)
     * @see core.ApplicationAbstract::defaultAction()
     */

    protected function defaultAction(Mekayotl_tools_Request $request)
    {
    }

    /**
     * Configura el render en caso de no ser AMFPHP\Gateway
     * @return ApplicationAbstract
     */

    protected function configRender($render = null)
    {
        return $render;
    }

    public static function validToken($tokenId)
    {
        $tokens = new App_saas_tables_Token();
        $token = new App_saas_vo_Token();
        $token->setNull();
        $token->url = Mekayotl_tools_Request::referer();
        $token->token = $tokenId;
        $tokens->read($token);
        if ($tokens->count() == 1) {
            return TRUE;
        }
        $app = self::singleton();
        $render = $app->classRender;
        return FALSE;
    }
    /**
     * Pagina de ingreso
     * @param string $user Usuario
     * @param string $password Contraseña
     */

    protected function login($user = NULL, $password = NULL)
    {
    }

    /**
     * Salir de la session.
     * @param unknown_type $token
     */

    protected function logout($token = NULL)
    {
    }

    public function tokenLogin($token)
    {
        $from = Mekayotl_tools_Request::referer();
        if(!$from){
            return FALSE;
        }
        $from = Mekayotl_tools_Request::parseURI('api://' . $from);
        $here = Mekayotl_tools_Request::parseURI();
        $subdomain = array_pop(array_diff($from->label, $here->label));
        $accounts = new App_saas_tables_ViewMemberAccount();
        $accounts->readByToken($token, $subdomain);
        if ($accounts->count() == 0) {
            return FALSE;
        }
        if ($accounts->count() == 1) {
            $memberAccount = $accounts->current();
            $subsrciptions = new App_saas_Subscription();
            $subscription = $memberAccount->subscription;
            $user = $memberAccount->nick;
            $password = $memberAccount->password;
            return $subsrciptions->login($subscription, $user, $password, TRUE);
        }
        return eval(Mekayotl_tools_Request::getBaseURL());
    }

    /**#@-*/

}

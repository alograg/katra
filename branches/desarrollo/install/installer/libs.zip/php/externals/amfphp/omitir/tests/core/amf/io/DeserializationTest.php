<?php

/**
 * tests for deserializing AMF objects
 *
 * @author: Ariel Sommeria-klein
 * Date: 28 oct. 2010
 * Time: 10:16:29
 */
require_once dirname(__FILE__) . '/Wrapper_AMFDeserializer.php';
require_once dirname(__FILE__) . '/AmfPhpTestData.php';

class DeserializationTest extends PHPUnit_Framework_TestCase {

    /**
     * tests for the deserialize method. Using a data provider messes with phpunit for nearly all cases so don't bother
     */
    public function testDeserializeMethod(){
        $testData = new AmfPhpTestData();


        $deserializer = new Wrapper_AMFDeserializer($testData->sEmptyMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
        $this->assertEquals($testData->dEmptyMessage, $amfObject);
        
        //those below don't work yet A.S.
        return;


        $deserializer = new Wrapper_AMFDeserializer($testData->sNullHeaderMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
        //$this->assertEquals($testData->ddNullHeaderMessage, $amfObject);

        $deserializer = new Wrapper_AMFDeserializer($testData->sStringHeaderMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
//        $this->assertEquals($testData->dStringHeaderMessage, $amfObject);

        $deserializer = new Wrapper_AMFDeserializer($testData->sNullBodyMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
        $this->assertEquals($testData->ddNullBodyMessage, $amfObject);

        $deserializer = new Wrapper_AMFDeserializer($testData->sStringBodyMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
        $this->assertEquals($testData->dStringBodyMessage, $amfObject);

        $deserializer = new Wrapper_AMFDeserializer($testData->s2Headers2BodiesMessage);
        $amfObject = new AMFObject();
        $deserializer->deserialize($amfObject);
        $this->assertEquals($testData->d2Headers2BodiesMessage, $amfObject);

    }
    
    /**
     * tests that mess up PHPunit when using the data provider mechanism
     */
    public function testMoreBasicMethods(){

        $testData = new AmfPhpTestData();

        $deserializer = new Wrapper_AMFDeserializer($testData->sObject);
        $read = $deserializer->readAny();
        $this->assertEquals($testData->dObject, $read);


        $deserializer = new Wrapper_AMFDeserializer($testData->sNull);
        $read = $deserializer->readAny();
        $this->assertEquals($testData->dNull, $read);

        //test here a bit different because we need to resolve an actual reference
        $deserializer = new Wrapper_AMFDeserializer($testData->sReference);
        $read = $deserializer->readAny();
        //TODO This fails because there is nothing to refer to. Do a real test
        //$this->assertEquals($testData->dReference, $read);

        $deserializer = new Wrapper_AMFDeserializer($testData->sEcmaArray);
        $read = $deserializer->readAny();
        //TODO this test currently fails with 1.9!!
        //$this->assertEquals($testData->dEcmaArray, $read);
        
    }
    
    public function basicMethodsProvider(){
        $testData = new AmfPhpTestData();
        return array(
            array("readByte", $testData->dByte, $testData->sByte),
            array("readInt", $testData->dInt, $testData->sInt),
            array("readLong", $testData->dLong, $testData->sLong),
            array("readDouble", $testData->dDouble, $testData->sDouble),
            array("readAny", $testData->dNumber, $testData->sNumber),
            array("readAny", $testData->dBoolean, $testData->sBoolean),
            array("readAny", $testData->dString, $testData->sString),
            //screws up phpunit
            //array("readAny", $testData->dObject, $testData->sObject),
            //screws up phpunit
            //array("readAny", $testData->dNull, $testData->sNull),
            //not supported yet
            //array("readAny", $testData->dUndefined, $testData->sUndefined),
            //screws up phpunit
            //array("readAny", $testData->dReference, $testData->sReference),
            //screws up phpunit
           // array("readAny", $testData->dEcmaArray, $testData->sEcmaArray),
            //not supported yet
            //array("readAny", $testData->dObjectEnd, $testData->sObjectEnd),
            array("readAny", $testData->dStrictArray, $testData->sStrictArray),
            array("readAny", $testData->dDate, $testData->sDate),
            //the readString reads either strings or long strings
            array("readAny", $testData->dLongString, $testData->sLongString),
            //not supported yet
            //array("readUnsupported", $testData->dUnsupported, $testData->sUnsupported),
            array("readAny", $testData->dXmlDocument, $testData->sXmlDocument),
            
            array("readAny", $testData->dTypedObjectAsArray, $testData->sTypedObject)
             );


    }


    /**
     *@dataProvider basicMethodsProvider
     *
     * @param <type> $methodName
     * @param <type> $expectedDeserialized
     * @param <type> $rawData
     */
    public function testBasicMethods($methodName, $expectedDeserialized, $rawData){
        //uncomment to check parameters passed to test
        //$this->assertFalse($methodName . "," . $expectedSerialized . ", " . bin2hex($rawData));
        $deserializer = new Wrapper_AMFDeserializer($rawData);
        $read = call_user_func(array($deserializer, $methodName));


        $this->assertEquals($expectedDeserialized, $read);
    }





}
?>

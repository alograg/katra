<?php
// $Id$

require_once dirname(__FILE__) . '/Wrapper_AMFSerializer.php';


$oAMFSerializer = new Wrapper_AMFSerializer();

// A value of NULL simply consists of the null-marker.
// The marker itself is the value-type.

// "null-marker" (0x01)

$oAMFSerializer->writeAmf3Null();

if ($oAMFSerializer->outBuffer !== "\1") {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}
?>
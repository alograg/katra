<?php
class HelloWorld
{
    public function say($sMessage)
    {
        return 'You said: ' . $sMessage;
    }
}
?>
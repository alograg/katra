<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DataProviderTest
 *
 * @author admin
 */

require_once dirname(__FILE__) . '/Wrapper_AMFSerializer.php';
require_once dirname(__FILE__) . '/Wrapper_AMFDeserializer.php';
require_once dirname(__FILE__) . '/AmfPhpTestData.php';

class SerializationTest extends PHPUnit_Framework_TestCase{

    /**
     * just empty here to avoid a warning in phpunit
     */
    public function testTest(){

    }
    
    /**
     *provider for the basic method tests
     * @return <array>
     */
    public function basicMethodsProvider()
    {
        $testData = new AmfPhpTestData();
        return array(
            array("writeByte", $testData->dByte, $testData->sByte),
            array("writeInt", $testData->dInt, $testData->sInt),
            array("writeLong", $testData->dLong, $testData->sLong),
            array("writeDouble", $testData->dDouble, $testData->sDouble),
            array("writeNumber", $testData->dNumber, $testData->sNumber),
            array("writeBoolean", $testData->dBoolean, $testData->sBoolean),
            array("writeString", $testData->dString, $testData->sString),
            // note: the serializer doesn't have a writeObject method, but rather a writeArray method that chooses between the Object, Strict Array and Ecma Array types
            // This strike me as inefficient, but for now it works, so keep it A.S.
            array("writeArray", $testData->dObject, $testData->sObject),
            array("writeNull", $testData->dNull, $testData->sNull),
            //not supported yet
            //array("writeUndefined", $testData->dUndefined, $testData->sUndefined),
            array("writeReference", $testData->dReference, $testData->sReference),
            array("writeArray", $testData->dEcmaArray, $testData->sEcmaArray),
            //not supported yet
            //array("writeObjectEnd", $testData->dObjectEnd, $testData->sObjectEnd),
            array("writeArray", $testData->dStrictArray, $testData->sStrictArray),
            array("writeDate", $testData->dDate, $testData->sDate),
            //the writeString writes either strings or long strings
            array("writeString", $testData->dLongString, $testData->sLongString),
            //not supported yet
            //array("writeUnsupported", $testData->dUnsupported, $testData->sUnsupported),
            array("writeXML", $testData->dXmlDocument, $testData->sXmlDocument),
            array("writeTypedObject", $testData->dTypedObject, $testData->sTypedObject)
        );
    }


    /**
     *@dataProvider basicMethodsProvider
     *
     * @param <String> $methodName. The name of the function on the serializer
     * @param <mixed> $input 
     * @param <mixed> $expectedSerialized
     */
    public function testBasicMethods($methodName, $input, $expectedSerialized){
        $serializer = new Wrapper_AMFSerializer();
        //uncomment to check parameters passed to test
        //$this->assertFalse($methodName . "," . $input . ", " . bin2hex($expectedSerialized));
        call_user_func(array($serializer, $methodName), $input);
        $serialized = $serializer->outBuffer;
        $this->assertEquals(bin2hex($expectedSerialized), bin2hex($serialized));
    }

    /**
     *provider for the serialize tests
     * @return <array>
     */
    public function serializeProvider()
    {
        $testData = new AmfPhpTestData();
        return array(
            array($testData->dEmptyMessage, $testData->sEmptyMessage),
            array($testData->dNullHeaderMessage, $testData->sNullHeaderMessage),
            array($testData->dStringHeaderMessage, $testData->sStringHeaderMessage),
            array($testData->dNullBodyMessage, $testData->sNullBodyMessage),
            array($testData->dStringBodyMessage, $testData->sStringBodyMessage),
            array($testData->d2Headers2BodiesMessage, $testData->s2Headers2BodiesMessage)
        );
    }

    /**
     *@dataProvider serializeProvider
     *note: this can't be fused with testBasicMethods because the "serialize" methods takes parameters by reference and this messes with
     * phpunit
     *
     * @param <type> $input
     * @param <type> $expectedSerialized
     */
    public function testSerializeMethod($input, $expectedSerialized){
        $serializer = new Wrapper_AMFSerializer();
        //uncomment to check parameters passed to test
        //$this->assertFalse(print_r($input, true) . ", " . bin2hex($expectedSerialized));
        $serializer->serialize($input);
        $serialized = $serializer->outBuffer;
        $this->assertEquals(bin2hex($expectedSerialized), bin2hex($serialized));
    }


    


}
?>

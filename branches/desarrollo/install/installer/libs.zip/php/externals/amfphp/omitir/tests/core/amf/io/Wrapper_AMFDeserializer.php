<?php
// $Id: Wrapper_AMFDeserializer.php 47 2010-11-01 18:53:28Z arielsom $

require_once dirname(__FILE__) . '/../../../../core/amf/app/Gateway.php';
require_once dirname(__FILE__) . '/../../../../core/shared/util/MessageBody.php'; 

require_once AMFPHP_BASE . 'amf/io/AMFDeserializer.php';


/**
 * This class exports some internal (protected) methods. This way, those methods
 * can be tested separately.
 */

class Wrapper_AMFDeserializer extends AMFDeserializer
{
    
}
?>
<?php
// $Id$

require_once dirname(__FILE__) . '/Wrapper_AMFSerializer.php';


$oAMFSerializer = new Wrapper_AMFSerializer();

// A 7 bit non-negative integer is serialised as U29-1.
// This method is not supposed to output the value type.

// bit 0-7 (0x01)

$oAMFSerializer->writeAmf3Int(1);

if ($oAMFSerializer->outBuffer !== "\1") {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}

$oAMFSerializer = new Wrapper_AMFSerializer();

// A negative integer is always serialised as U29-4.
// This method is not supposed to output the value type.

// For a "-1", all bits are set.
// All four bytes thus are "255".

$oAMFSerializer->writeAmf3Int(-1);

if ($oAMFSerializer->outBuffer !== pack('C4', 255, 255, 255, 255)) {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}

$oAMFSerializer = new Wrapper_AMFSerializer();

// An 8 bit non-negative integer is serialised as U29-2.
// The higher 7 bits are in the first byte, the remaining 7 bits in the second byte (0-based).
// 130 = 128(7th) + 2(1nd)

// bit 7-13 (0x01) plus continuation flag (0x80) = 0x80 + 0x01 = 0x81
// bit 0-6 without continuation flag = 0x02

$oAMFSerializer->writeAmf3Int(130);

if (($sBuffer=$oAMFSerializer->outBuffer) !== pack('CC', 129, 2)) {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}
?>
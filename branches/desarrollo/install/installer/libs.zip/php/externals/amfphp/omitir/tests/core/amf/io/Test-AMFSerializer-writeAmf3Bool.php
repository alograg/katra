<?php
// $Id$

require_once dirname(__FILE__) . '/Wrapper_AMFSerializer.php';


$oAMFSerializer = new Wrapper_AMFSerializer();

// A value of TRUE simply consists of the true-marker.
// The marker itself is the value-type.

// "true-marker" (0x01)

$oAMFSerializer->writeAmf3Bool(TRUE);

if ($oAMFSerializer->outBuffer !== "\3") {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}

$oAMFSerializer = new Wrapper_AMFSerializer();

// A value of FALSE simply consists of the false-marker.
// The marker itself is the value-type.

// "false-marker" (0x02)

$oAMFSerializer->writeAmf3Bool(FALSE);

if ($oAMFSerializer->outBuffer !== "\2") {
    echo 'Failed at line ' . __LINE__ . '!' . "\n";
}
?>
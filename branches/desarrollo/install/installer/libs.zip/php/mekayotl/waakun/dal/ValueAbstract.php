<?php
namespace core\waakun\dal;
/**
 * Abstact del acceso a base de datos por Waakun
 *
 * @author	Henry I. Galvez T. <alograg@alograg.me>
 * @copyright	Copyright (c) 2008, {@link http://www.aquainteractive.com Aqua Interactive}
 * @package	Mekayotl.Waakun
 * @since	2011-03-01
 * @subpackage	dal
 * @version	$Id$
 */

/**
 * Abstact de Valores de base de datos por Waakun
 *
 * Define funciones basicas y funciones que se deben de implementar una table de waakun.
 * @package	Mekayotl.Waakun
 * @subpackage	dal
 * @abstract
 */
abstract class ValueAbstract {
	public function asWhere(){
		$return = new \core\database\WhereCollection((array) $this);
		return $return;
	}
	public function __toString(){
		$return = $this->asWhere();
		return (string) $return;
	}
}
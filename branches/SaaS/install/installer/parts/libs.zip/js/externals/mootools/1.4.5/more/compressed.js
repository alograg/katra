// MooTools: the javascript framework.
// Load this file's selection again by visiting: http://mootools.net/more/842954a479468aaefe1cf61635b399c7 
// Or build this file again with packager using: packager build More/More
/*
---
copyrights:
  - [MooTools](http://mootools.net)

licenses:
  - [MIT License](http://mootools.net/license.txt)
...
*/
MooTools.More={version:"1.4.0.1",build:"a4244edf2aa97ac8a196fc96082dd35af1abab87"};